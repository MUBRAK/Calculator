package com.ideaGen.coding.exercise;

import java.util.Stack;

public class MathCalculator {
    public static void main(String[] args) {
    String equation="( 11.5 + 15.4 ) + 10.1"; // 2.0 ,

       System.out.println(calculate(equation));
    }
    public static double calculate(String equation){
        Stack<Double> numbers = new Stack<>();
        Stack<String> operations = new Stack<>();
        String[] value = equation.split(" ");

        for(int i=0;i<value.length;i++)
        {
            if (value[i].equals("+" ) || value[i].equals("-")  ||
                    value[i].equals("*") || value[i].equals("/") )
            {
                operations.push(value[i]);

            }else if (value[i].equals("(")){
                operations.push(value[i]);
            }else if (value[i].equals(")")){
                while (!operations.peek().equals("(")){ // now need to calculate the inner expression
                numbers.push(calculateEquation(operations.pop(), numbers.pop(), numbers.pop()));
                }
                    operations.pop();// need to remove ( from the operations stack
            }else{
                numbers.push(Double.parseDouble(String.valueOf(value[i])));
            }
        }
        while (!operations.empty()) {
            numbers.push(calculateEquation(operations.pop(), numbers.pop(), numbers.pop()));
        }

        return numbers.pop();
    }
    public static double calculateEquation(String operation, double num2, double num1)
    {
        switch (operation)
        {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                if(num2==0){
                    throw new ArithmeticException("Cannot divide by zero");
                }
                return num1 / num2;
        }
        return 0;
    }
}
